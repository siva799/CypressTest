export default{   
    heading: "Dynamic Table",
    columnNames:["name","age","gender"]
}