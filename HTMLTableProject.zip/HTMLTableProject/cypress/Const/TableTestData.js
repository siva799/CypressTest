export default{   
    label: "Dynamic Table",
    headerData:["name","age","gender"]
}